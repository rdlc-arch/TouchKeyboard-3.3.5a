-- TouchKeyboard for WoW 3.3.5a
-- On-screen touch keyboard that pops up when any text box (chat, mail, AH...) gets focus.
-- Slash: /tkb  (toggle)  /tkb reset  /tkb autohide  /tkb autoshow  /tkb launcher

local ADDON = ...

local KEY, GAP, PAD, TITLE = 44, 4, 8, 24   -- KEY = key size in px (touch friendly)
local COLS = 10

local defaults = { scale = 1.0, autoShow = true, autoHide = true, launcher = true }
local db, target
local shift, lastShift = 0, 0               -- 0 off, 1 one-shot, 2 caps lock
local page = "abc"
local pages, letterKeys = {}, {}
local shiftKey
local Press                                 -- forward declaration

local frameBackdrop = {
  bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
  edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
  tile = true, tileSize = 16, edgeSize = 16,
  insets = { left = 4, right = 4, top = 4, bottom = 4 },
}
local keyBackdrop = {
  bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
  edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
  tile = true, tileSize = 16, edgeSize = 10,
  insets = { left = 2, right = 2, top = 2, bottom = 2 },
}

local layouts = {
  abc = {
    { "1","2","3","4","5","6","7","8","9","0" },
    { "q","w","e","r","t","y","u","i","o","p" },
    { "a","s","d","f","g","h","j","k","l","'" },
    { {k="SHIFT",w=1.5,l="Shift"}, "z","x","c","v","b","n","m", {k="BACK",w=1.5,l="Del"} },
  },
  sym = {
    { "1","2","3","4","5","6","7","8","9","0" },
    { "!","@","#","$","%","^","&","*","(",")" },
    { "-","_","=","+","[","]",";",":","'","\"" },
    { {k="ESC",l="Esc"}, ",","?","\\","|","~","`","{","}", {k="BACK",l="Del"} },
  },
}
local bottomRow = {
  {k="MODE",w=1.5}, "/", {k="SPACE",w=3.5,l="space"}, ".", {k="ENTER",w=2,l="Enter"}, {k="HIDE",l="Hide"},
}

local function Msg(t) DEFAULT_CHAT_FRAME:AddMessage("|cff66ccffTouchKeyboard:|r " .. t) end

---------------------------------------------------------------------------
-- Main frame
---------------------------------------------------------------------------
local TK = CreateFrame("Frame", "TouchKeyboardFrame", UIParent)
local W = PAD * 2 + COLS * KEY + (COLS - 1) * GAP
local H = TITLE + PAD * 2 + 5 * KEY + 4 * GAP
TK:SetWidth(W); TK:SetHeight(H)
TK:SetFrameStrata("DIALOG")
TK:SetClampedToScreen(true)
TK:SetMovable(true)
TK:EnableMouse(true)
TK:SetBackdrop(frameBackdrop)
TK:SetBackdropColor(0, 0, 0, 0.85)
TK:SetBackdropBorderColor(0.6, 0.6, 0.6, 1)
TK:Hide()

local function SavePos(f, key)
  local p, _, rp, x, y = f:GetPoint()
  db[key] = { p, rp, x, y }
end

local function RestorePos(f, key, dp, dx, dy)
  f:ClearAllPoints()
  local s = db[key]
  if s then f:SetPoint(s[1], UIParent, s[2], s[3], s[4])
  else f:SetPoint(dp, UIParent, dp, dx, dy) end
end

---------------------------------------------------------------------------
-- Title bar: drag to move, -/+ to resize, X to close
---------------------------------------------------------------------------
local title = CreateFrame("Frame", nil, TK)
title:SetPoint("TOPLEFT", 4, -4)
title:SetPoint("TOPRIGHT", -4, -4)
title:SetHeight(TITLE)
title:EnableMouse(true)
title:RegisterForDrag("LeftButton")
title:SetScript("OnDragStart", function() TK:StartMoving() end)
title:SetScript("OnDragStop", function() TK:StopMovingOrSizing(); SavePos(TK, "pos") end)

local tt = title:CreateFontString(nil, "OVERLAY", "GameFontNormal")
tt:SetPoint("LEFT", 6, 0)
tt:SetText("TouchKeyboard  |cff888888(drag here)|r")

local function SetScaleBy(d)
  local s = (db.scale or 1) + d
  s = math.floor(math.max(0.5, math.min(2.5, s)) * 10 + 0.5) / 10
  db.scale = s
  TK:SetScale(s)
end

local function TitleButton(label, xOff, fn)
  local b = CreateFrame("Button", nil, title, "UIPanelButtonTemplate")
  b:SetWidth(30); b:SetHeight(20)
  b:SetPoint("RIGHT", xOff, 0)
  b:SetText(label)
  b:SetScript("OnClick", fn)
  return b
end
TitleButton("X", -2, function() Press("HIDE") end)
TitleButton("+", -36, function() SetScaleBy(0.1) end)
TitleButton("-", -70, function() SetScaleBy(-0.1) end)

---------------------------------------------------------------------------
-- Keys
---------------------------------------------------------------------------
local function KeyWidth(w) return w * KEY + (w - 1) * GAP end

local function SetPressed(b, on)
  if on then b:SetBackdropColor(0.4, 0.4, 0.55, 1)
  else b:SetBackdropColor(unpack(b.bg)) end
end

local function MakeKey(parent, def, x, y)
  if type(def) == "string" then def = { k = def } end
  local special = #def.k > 1
  local w = KeyWidth(def.w or 1)
  local b = CreateFrame("Button", nil, parent)
  b:SetWidth(w); b:SetHeight(KEY)
  b:SetPoint("TOPLEFT", parent, "TOPLEFT", x, -y)
  b:SetBackdrop(keyBackdrop)
  b.bg = special and { 0.18, 0.18, 0.22, 0.95 } or { 0.07, 0.07, 0.07, 0.95 }
  b:SetBackdropColor(unpack(b.bg))
  b:SetBackdropBorderColor(0.5, 0.5, 0.5, 1)

  local fs = b:CreateFontString(nil, "OVERLAY")
  fs:SetFont(STANDARD_TEXT_FONT, special and 14 or 20, "OUTLINE")
  fs:SetPoint("CENTER")
  fs:SetText(def.l or def.k)
  b.text, b.key = fs, def.k

  b:RegisterForClicks("LeftButtonUp")
  b:SetScript("OnMouseDown", function(self)
    SetPressed(self, true)
    if self.key == "BACK" then Press("BACK"); self.hold = 0 end
  end)
  b:SetScript("OnMouseUp", function(self) SetPressed(self, false); self.hold = nil end)
  b:SetScript("OnHide", function(self) SetPressed(self, false); self.hold = nil end)

  if def.k == "BACK" then
    -- hold Del to keep deleting
    b:SetScript("OnUpdate", function(self, el)
      if not self.hold then return end
      self.hold = self.hold + el
      if self.hold > 0.45 then Press("BACK"); self.hold = 0.37 end
    end)
  else
    b:SetScript("OnClick", function(self) Press(self.key) end)
  end
  return b, w
end

local function BuildPage(name, rows)
  local p = CreateFrame("Frame", nil, TK)
  p:SetAllPoints(TK)
  local all = {}
  for i, r in ipairs(rows) do all[i] = r end
  all[#all + 1] = bottomRow

  for ri, row in ipairs(all) do
    local units = 0
    for _, d in ipairs(row) do units = units + (type(d) == "table" and (d.w or 1) or 1) end
    local rowW = units * KEY + (units - 1) * GAP
    local x = PAD + (COLS * KEY + (COLS - 1) * GAP - rowW) / 2
    local y = TITLE + PAD + (ri - 1) * (KEY + GAP)
    for _, d in ipairs(row) do
      local b, w = MakeKey(p, d, x, y)
      if #b.key == 1 and b.key:match("%a") then letterKeys[#letterKeys + 1] = b end
      if b.key == "SHIFT" then shiftKey = b end
      if b.key == "MODE" then b.text:SetText(name == "abc" and "?123" or "ABC") end
      x = x + w + GAP
    end
  end
  p:Hide()
  pages[name] = p
end

local function ShowPage(name)
  for n, p in pairs(pages) do if n == name then p:Show() else p:Hide() end end
  page = name
end

local function UpdateShift()
  for _, b in ipairs(letterKeys) do
    b.text:SetText(shift > 0 and b.key:upper() or b.key)
  end
  if shiftKey then
    shiftKey.bg = (shift == 2 and { 0.15, 0.45, 0.15, 1 })
               or (shift == 1 and { 0.25, 0.25, 0.55, 1 })
               or { 0.18, 0.18, 0.22, 0.95 }
    shiftKey:SetBackdropColor(unpack(shiftKey.bg))
    shiftKey.text:SetText(shift == 2 and "CAPS" or "Shift")
  end
end

---------------------------------------------------------------------------
-- Typing into the focused edit box
---------------------------------------------------------------------------
local function EnsureTarget()
  local focus = GetCurrentKeyBoardFocus()
  if focus then target = focus; return target end

  -- lost focus: re-activate the last box, or open chat
  if target and target.chatFrame and ChatEdit_ActivateChat then
    ChatEdit_ActivateChat(target)
  elseif target and target:IsVisible() then
    target:SetFocus()
  else
    target = nil
    if ChatFrame_OpenChat then ChatFrame_OpenChat("") end
    target = GetCurrentKeyBoardFocus()
  end
  return target
end

local function Backspace(eb)
  local text = eb:GetText() or ""
  local pos = eb.GetCursorPosition and eb:GetCursorPosition() or #text
  if pos <= 0 then return end
  local s = pos
  -- step back over UTF-8 continuation bytes
  while s > 1 and text:byte(s) and text:byte(s) >= 128 and text:byte(s) < 192 do s = s - 1 end
  eb:SetText(text:sub(1, s - 1) .. text:sub(pos + 1))
  if eb.SetCursorPosition then eb:SetCursorPosition(s - 1) end
end

Press = function(key)
  if key == "SHIFT" then
    local now = GetTime()
    if shift == 1 and now - lastShift < 0.4 then shift = 2
    elseif shift > 0 then shift = 0
    else shift = 1 end
    lastShift = now
    UpdateShift()
    return
  elseif key == "MODE" then
    ShowPage(page == "abc" and "sym" or "abc")
    return
  elseif key == "HIDE" then
    TK.dismissed = GetCurrentKeyBoardFocus() ~= nil
    TK.manual = nil
    TK:Hide()
    return
  end

  local eb = EnsureTarget()
  if not eb then return end

  if key == "BACK" then
    Backspace(eb)
  elseif key == "SPACE" then
    eb:Insert(" ")
  elseif key == "ENTER" then
    local f = eb:GetScript("OnEnterPressed")
    if f then f(eb) end
  elseif key == "ESC" then
    local f = eb:GetScript("OnEscapePressed")
    if f then f(eb) else eb:ClearFocus() end
  else
    local ch = key
    if shift > 0 and ch:match("%a") then ch = ch:upper() end
    eb:Insert(ch)
    if shift == 1 then shift = 0; UpdateShift() end
  end
end

---------------------------------------------------------------------------
-- Launcher button: tap = open chat + keyboard, drag = move
---------------------------------------------------------------------------
local L = CreateFrame("Button", "TouchKeyboardLauncher", UIParent)
L:SetWidth(56); L:SetHeight(44)
L:SetFrameStrata("DIALOG")
L:SetClampedToScreen(true)
L:SetMovable(true)
L:SetBackdrop(keyBackdrop)
L:SetBackdropColor(0.1, 0.1, 0.2, 0.9)
L:SetBackdropBorderColor(0.6, 0.6, 0.8, 1)
local lt = L:CreateFontString(nil, "OVERLAY")
lt:SetFont(STANDARD_TEXT_FONT, 16, "OUTLINE")
lt:SetPoint("CENTER")
lt:SetText("Chat")
L:RegisterForClicks("LeftButtonUp")
L:RegisterForDrag("LeftButton")
L:SetScript("OnMouseDown", function(self) self.moved = nil end)
L:SetScript("OnDragStart", function(self) self.moved = true; self:StartMoving() end)
L:SetScript("OnDragStop", function(self) self:StopMovingOrSizing(); SavePos(self, "lpos") end)
L:SetScript("OnClick", function(self)
  if self.moved then self.moved = nil; return end
  if TK:IsShown() then
    Press("HIDE")
  else
    if not GetCurrentKeyBoardFocus() and ChatFrame_OpenChat then ChatFrame_OpenChat("") end
    TK.dismissed, TK.manual = nil, nil
    TK:Show()
  end
end)

---------------------------------------------------------------------------
-- Auto show / hide when a text box gains / loses focus
---------------------------------------------------------------------------
local poll = CreateFrame("Frame")
local acc, idle = 0, 0
poll:SetScript("OnUpdate", function(_, el)
  if not db then return end
  acc = acc + el
  if acc < 0.1 then return end
  local dt = acc; acc = 0

  local f = GetCurrentKeyBoardFocus()
  if f then
    idle = 0
    if f ~= target then target = f; TK.dismissed = nil end
    if db.autoShow and not TK:IsShown() and not TK.dismissed then TK:Show() end
  else
    idle = idle + dt
    TK.dismissed = nil
    if db.autoHide and TK:IsShown() and not TK.manual and idle > 0.6 then TK:Hide() end
  end
end)

---------------------------------------------------------------------------
-- Init + slash commands
---------------------------------------------------------------------------
TK:RegisterEvent("ADDON_LOADED")
TK:SetScript("OnEvent", function(self, event, name)
  if name ~= ADDON then return end
  self:UnregisterEvent("ADDON_LOADED")
  TouchKeyboardDB = TouchKeyboardDB or {}
  db = TouchKeyboardDB
  for k, v in pairs(defaults) do if db[k] == nil then db[k] = v end end

  BuildPage("abc", layouts.abc)
  BuildPage("sym", layouts.sym)
  ShowPage("abc")
  UpdateShift()

  TK:SetScale(db.scale)
  RestorePos(TK, "pos", "BOTTOM", 0, 120)
  RestorePos(L, "lpos", "BOTTOMLEFT", 20, 260)
  if db.launcher then L:Show() else L:Hide() end
end)

SLASH_TOUCHKEYBOARD1 = "/tkb"
SlashCmdList["TOUCHKEYBOARD"] = function(msg)
  msg = ((msg or ""):lower()):match("^%s*(.-)%s*$")
  if msg == "reset" then
    db.pos, db.lpos, db.scale = nil, nil, 1
    TK:SetScale(1)
    RestorePos(TK, "pos", "BOTTOM", 0, 120)
    RestorePos(L, "lpos", "BOTTOMLEFT", 20, 260)
    Msg("position and size reset.")
  elseif msg == "autohide" then
    db.autoHide = not db.autoHide
    Msg("auto-hide " .. (db.autoHide and "ON" or "OFF"))
  elseif msg == "autoshow" then
    db.autoShow = not db.autoShow
    Msg("auto-show " .. (db.autoShow and "ON" or "OFF"))
  elseif msg == "launcher" then
    db.launcher = not db.launcher
    if db.launcher then L:Show() else L:Hide() end
    Msg("launcher button " .. (db.launcher and "shown" or "hidden"))
  else
    if TK:IsShown() then Press("HIDE")
    else TK.manual, TK.dismissed = true, nil; TK:Show() end
  end
end
